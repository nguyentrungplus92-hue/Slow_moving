from sap_odata_client import connect_sap_rfc, rfc_read_table_all,fetch_sap_odata_all


conn = connect_sap_rfc(ashost='hana.cmcconsulting.vn', sysnr='12', client='120',
                       user='locnx', passwd='Lockhongvui98')

# fields = ["MATNR","MTART","MEINS","ERSDA","ERNAM","LAEDA","AENAM", "CREATED_AT_TIME", "PSTAT", "LVORM","MATKL", "BSTME", "ZEINR", "ZEIAR", "ZEIVR"]  # nhiều field thoải mái
fields = ["MATNR","MTART","ERSDA","ERNAM","EXTWG"]  # nhiều field thoải mái
# condition = "'TEXT':"()""
data = rfc_read_table_all(conn, "MARA", fields,options=["MATNR = '000000000000000116'"], page_size=1000)

print(len(data))
print(data[:1])

all_products = fetch_sap_odata_all(
        base_url="http://hana.cmcconsulting.vn:8012",
        odata_root="/sap/opu/odata/sap/",
        service_name="API_PRODUCT_SRV",
        entity_set="A_Product",
        key=None,
        select= None,                        #"Material,Plant,StorageLocation,MatlWrhsStkQtyInMatlBaseUnit,MaterialBaseUnit",
        filter_=None,
        expand=None,
        fmt="json",
        username="locnx",
        password="Lockhongvui98"
)

print("=== Kết quả ALL page ===")
print("Tổng số dòng:", len(all_products))
# print(all_products)