from ..src.sap_odata_client.sap_rfc import connect_sap_rfc, rfc_read_table_all

conn = connect_sap_rfc(ashost='hana.cmcconsulting.vn', sysnr='12', client='120',
                       user='locnx', passwd='Lockhongvui98')

# fields = ["MATNR","MTART","MEINS","ERSDA","ERNAM","LAEDA","AENAM", "CREATED_AT_TIME", "PSTAT", "LVORM","MATKL", "BSTME", "ZEINR", "ZEIAR", "ZEIVR"]  # nhiều field thoải mái
fields = ["MATNR","MTART","ERSDA","ERNAM","EXTWG"]  # nhiều field thoải mái
# condition = "'TEXT':"()""
data = rfc_read_table_all(conn, "MARA", fields,options=["MATNR = '000000000000000116'"], page_size=1000)

print(len(data))
print(data[:1])
