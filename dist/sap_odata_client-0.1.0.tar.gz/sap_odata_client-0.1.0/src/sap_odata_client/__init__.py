# sap_odata_client/__init__.py

from .data import (
    build_sap_odata_url,
    fetch_sap_odata,
    fetch_sap_odata_all,
    get_odata_results,
)

# ✅ thêm OData->RFC mapping helpers
from .mapping import (
    get_mapping,
    map_odata_records_to_rfc_like,
)

# ✅ thêm RFC helpers
from .sap_rfc import (
    connect_sap_rfc,
    rfc_read_table_all,
)

__all__ = [
    # OData
    "build_sap_odata_url",
    "fetch_sap_odata",
    "fetch_sap_odata_all",
    "get_odata_results",

    # Mapping
    "get_mapping",
    "map_odata_records_to_rfc_like",

    # RFC
    "connect_sap_rfc",
    "rfc_read_table_all",
]
