# sap_rfc.py
from __future__ import annotations
from typing import List, Dict, Any, Optional, Sequence, Tuple

def connect_sap_rfc(ashost, sysnr, client, user, passwd, lang="EN"):
    from pyrfc import Connection  # lazy import để package không crash khi chưa có SDK
    return Connection(
        ashost=ashost,
        sysnr=sysnr,
        client=client,
        user=user,
        passwd=passwd,
        lang=lang
    )

def _normalize_options(options: Optional[Sequence[Any]]) -> List[Dict[str, str]]:
    # nhận options dạng ["A = '1'", "AND B = '2'"] hoặc [{"TEXT": "..."}]
    if not options:
        return []
    if isinstance(options[0], dict):
        return list(options)  # type: ignore
    return [{"TEXT": str(x)} for x in options]  # type: ignore

def _pad(values: List[str], n: int) -> List[str]:
    if len(values) < n:
        values += [""] * (n - len(values))
    return values[:n]

def _chunk_fields_by_len(fields: Sequence[str], field_lens: Dict[str, int],
                         max_wa_len: int = 480, delimiter_len: int = 1) -> List[List[str]]:
    """
    Chia fields thành nhiều chunk dựa trên độ dài ước lượng.
    max_wa_len nên < 512 để chừa buffer.
    """
    chunks: List[List[str]] = []
    cur: List[str] = []
    cur_len = 0

    for f in fields:
        f = f.strip().upper()
        need = field_lens.get(f, 10) + delimiter_len  # fallback 10 nếu không biết
        if cur and (cur_len + need) > max_wa_len:
            chunks.append(cur)
            cur = []
            cur_len = 0
        cur.append(f)
        cur_len += need

    if cur:
        chunks.append(cur)
    return chunks

def _get_field_lengths_dd03l(conn, table: str, fields: Sequence[str]) -> Dict[str, int]:
    """
    Lấy LENG của các field từ DD03L để estimate chunk.
    Đọc theo từng field (nhanh hơn đọc cả bảng DD03L).
    """
    table = table.strip().upper()
    wanted = {f.strip().upper() for f in fields}
    if not wanted:
        return {}

    # DD03L: TABNAME, FIELDNAME, LENG
    res = conn.call(
        "RFC_READ_TABLE",
        QUERY_TABLE="DD03L",
        DELIMITER="|",
        FIELDS=[{"FIELDNAME": "FIELDNAME"}, {"FIELDNAME": "LENG"}],
        OPTIONS=[
            {"TEXT": f"TABNAME = '{table}'"},
            {"TEXT": "AND AS4LOCAL = 'A'"},
        ],
        ROWCOUNT=0,
        ROWSKIPS=0
    )

    lens: Dict[str, int] = {}
    for r in res.get("DATA", []) or []:
        parts = (r.get("WA") or "").split("|")
        if len(parts) >= 2:
            fname = parts[0].strip().upper()
            if fname in wanted:
                try:
                    lens[fname] = int(parts[1].strip() or "0")
                except ValueError:
                    lens[fname] = 0

    # fallback độ dài tối thiểu để tránh chunk quá to
    for f in wanted:
        lens.setdefault(f, 10)
    return lens

def rfc_read_table_all(conn, table, fields, options=None, page_size=2000, delimiter="|"):
    results = []
    rowskips = 0
    req_fields = [f.strip().upper() for f in fields]

    while True:
        res = conn.call(
            "RFC_READ_TABLE",
            QUERY_TABLE=table,
            DELIMITER=delimiter,
            ROWSKIPS=rowskips,
            ROWCOUNT=page_size,
            FIELDS=[{"FIELDNAME": f} for f in req_fields],
            OPTIONS=[{"TEXT": o} for o in (options or [])]
        )

        data = res.get("DATA", []) or []
        if not data:
            break

        # ✅ field order thật sự theo SAP trả về
        sap_fields = [f["FIELDNAME"].strip().upper() for f in (res.get("FIELDS", []) or [])]
        if not sap_fields:
            sap_fields = req_fields  # fallback

        for r in data:
            values = (r.get("WA") or "").split(delimiter)
            if len(values) < len(sap_fields):
                values += [""] * (len(sap_fields) - len(values))

            row_dict = dict(zip(sap_fields, values[:len(sap_fields)]))

            # ✅ reorder lại theo thứ tự bạn yêu cầu
            results.append({f: row_dict.get(f, "") for f in req_fields})

        rowskips += len(data)
        if len(data) < page_size:
            break

    return results
