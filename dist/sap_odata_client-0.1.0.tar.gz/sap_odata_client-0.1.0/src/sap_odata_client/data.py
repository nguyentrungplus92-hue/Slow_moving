import requests
from requests.auth import HTTPBasicAuth
from urllib.parse import urlencode

from .mapping import get_mapping, map_odata_records_to_rfc_like


# ============================================================
# 1. BUILD ODATA URL (OData V2 đầy đủ)
# ============================================================

def build_sap_odata_url(
    base_url: str,
    odata_root: str = "/sap/opu/odata/sap/",
    service_name: str = "API_PRODUCT_SRV",
    entity_set: str = "A_Product",
    key: str | None = None,

    select: str | None = None,
    filter_: str | None = None,
    expand: str | None = None,

    top: int | None = None,
    skip: int | None = None,
    orderby: str | None = None,
    inlinecount: str | None = None,   # "allpages"

    fmt: str | None = "json",
) -> str:

    base = base_url.rstrip("/")
    root = odata_root.rstrip("/") + "/"
    service = service_name.strip("/")
    entity = entity_set.strip("/")

    path = f"{base}{root}{service}/{entity}"
    if key:
        path += f"('{key}')"

    params = {}

    if select:
        params["$select"] = select
    if filter_:
        params["$filter"] = filter_
    if expand:
        params["$expand"] = expand
    if top is not None:
        params["$top"] = str(top)
    if skip is not None:
        params["$skip"] = str(skip)
    if orderby:
        params["$orderby"] = orderby
    if inlinecount:
        params["$inlinecount"] = inlinecount
    if fmt:
        params["$format"] = fmt

    if params:
        query = urlencode(params, safe=",$()' ")
        return f"{path}?{query}"

    return path


# ============================================================
# 2. GỌI ODATA 1 PAGE
# ============================================================

def fetch_sap_odata(
    base_url: str,
    odata_root: str = "/sap/opu/odata/sap/",
    service_name: str = "API_PRODUCT_SRV",
    entity_set: str = "A_Product",
    key: str | None = None,

    select: str | None = None,
    filter_: str | None = None,
    expand: str | None = None,

    top: int | None = None,
    skip: int | None = None,
    orderby: str | None = None,
    inlinecount: str | None = None,

    fmt: str | None = "json",
    username: str | None = None,
    password: str | None = None,
):
    url = build_sap_odata_url(
        base_url=base_url,
        odata_root=odata_root,
        service_name=service_name,
        entity_set=entity_set,
        key=key,
        select=select,
        filter_=filter_,
        expand=expand,
        top=top,
        skip=skip,
        orderby=orderby,
        inlinecount=inlinecount,
        fmt=fmt,
    )

    print("=== URL gọi OData ===")
    print(url)

    headers = {"Accept": "application/json"} if fmt == "json" else {}
    auth = HTTPBasicAuth(username, password) if username and password else None

    resp = requests.get(url, headers=headers, auth=auth)
    print("Status code:", resp.status_code)
    resp.raise_for_status()

    return resp.json() if fmt == "json" else resp.text


# ============================================================
# 2.1 PARSE RESULTS
# ============================================================

def get_odata_results(data: dict) -> list[dict]:
    if not isinstance(data, dict) or "d" not in data:
        return []

    d = data["d"]

    if isinstance(d, dict) and "results" in d:
        return d["results"]

    if isinstance(d, dict):
        return [d]

    return []


# ============================================================
# 2.2 GỌI ODATA ALL PAGE (THEO __next)
# ============================================================

def fetch_sap_odata_all(
    base_url: str,
    odata_root: str = "/sap/opu/odata/sap/",
    service_name: str = "API_PRODUCT_SRV",
    entity_set: str = "A_Product",
    key: str | None = None,

    select: str | None = None,
    filter_: str | None = None,
    expand: str | None = None,

    top: int | None = None,
    skip: int | None = None,
    orderby: str | None = None,
    inlinecount: str | None = None,

    fmt: str | None = "json",
    username: str | None = None,
    password: str | None = None,

    apply_mapping: bool = True,
):
    # --- PAGE ĐẦU ---
    data = fetch_sap_odata(
        base_url=base_url,
        odata_root=odata_root,
        service_name=service_name,
        entity_set=entity_set,
        key=key,
        select=select,
        filter_=filter_,
        expand=expand,
        top=top,
        skip=skip,
        orderby=orderby,
        inlinecount=inlinecount,
        fmt=fmt,
        username=username,
        password=password,
    )

    all_results = get_odata_results(data)

    auth = HTTPBasicAuth(username, password) if username and password else None
    headers = {"Accept": "application/json"} if fmt == "json" else {}

    next_url = data.get("d", {}).get("__next")

    while next_url:
        print("=== Gọi page tiếp theo ===")
        print(next_url)

        resp = requests.get(next_url, headers=headers, auth=auth)
        print("Status code:", resp.status_code)
        resp.raise_for_status()

        data_next = resp.json()
        all_results.extend(get_odata_results(data_next))
        next_url = data_next.get("d", {}).get("__next")

    # --- APPLY MAPPING (NẾU CÓ) ---
    if apply_mapping:
        mapping = get_mapping(service_name, entity_set)
        if mapping:
            return map_odata_records_to_rfc_like(
                all_results,
                mapping,
                pad=True,
                convert_date=True,
                keep_unmapped=True,
                preserve_odata_order=True,
            )

    return all_results


# ============================================================
# 3. CHẠY THỬ
# ============================================================

if __name__ == "__main__":
    # --- TRƯỜNG HỢP 1: GỌI 1 LẦN (1 PAGE) ---
    # data_one_page = fetch_sap_odata(
    #     base_url="http://hana.cmcconsulting.vn:8012",
    #     odata_root="/sap/opu/odata/sap/",
    #     service_name="API_PRODUCT_SRV",
    #     entity_set="A_Product",
    #     key=None,
    #     select="Product,CreationDate,CreatedByUser,ProductType,ExternalProductGroup",
    #     filter_="Product eq 'MONITOR' or Product eq 'MOUSE'",   # ví dụ: "Product eq 'MONITOR' or Product eq 'MOUSE'"
    #     expand=None,
    #     fmt="json",
    #     username="locnx",
    #     password="Lockhongvui98"
    # )

    # print("=== Kết quả 1 page ===")
    # results_one = get_odata_results(data_one_page)
    # print("Số dòng (1 page):", len(results_one))
    # for r in results_one:
    #     print(r["Product"])

    # --- TRƯỜNG HỢP 2: GỌI HẾT NHIỀU PAGE ---
    all_products = fetch_sap_odata_all(
        base_url="http://hana.cmcconsulting.vn:8012",
        odata_root="/sap/opu/odata/sap/",
        service_name="API_PRODUCT_SRV",
        entity_set="A_Product",
        key=None,
        select= "Product,CreationDate,CreatedByUser,ProductType,ExternalProductGroup",                        #"Material,Plant,StorageLocation,MatlWrhsStkQtyInMatlBaseUnit,MaterialBaseUnit",
        filter_="Product eq '000000000000000007' or Product eq '000000000000000170'",
        expand=None,
 
        fmt="json",
        username="locnx",
        password="Lockhongvui98"
    )

    print("=== Kết quả ALL page ===")
    print("Tổng số dòng:", len(all_products))
    print(all_products)
    # for r in all_products:
    #     print(r)
