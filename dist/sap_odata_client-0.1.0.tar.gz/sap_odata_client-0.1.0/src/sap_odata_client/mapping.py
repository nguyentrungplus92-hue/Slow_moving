# mapping.py
# ============================================================
# Mapping OData -> RFC-like (theo từng Service / Entity Set)
# ============================================================

from typing import Dict, List, Callable
import re
from datetime import datetime, timezone


# ============================================================
# 1) Mapping theo SERVICE + ENTITY_SET
#    Key   : RFC field (bảng SAP như MARA, MSEG…)
#    Value : Field trả về từ OData
# ============================================================

SERVICE_ENTITY_MAPPINGS: Dict[str, Dict[str, Dict[str, str]]] = {

    # ========================================================
    # API_PRODUCT_SRV / A_Product  ~ MARA + MARC
    # ========================================================
    "API_PRODUCT_SRV": {
        "A_Product": {
            "MATNR": "Product",
            "MTART": "ProductType",
            "ERSDA": "CreationDate",
            "ERNAM": "CreatedByUser",
            "EXTWG": "ExternalProductGroup",
            # có thể mở rộng:
            # "LAEDA": "LastChangeDate",
            # "AENAM": "LastChangedByUser",
        },

        "A_ProductPlant": {
            "MATNR": "Product",
            "WERKS": "Plant",
            "EKGRP": "PurchasingGroup",
            "PRCTR": "ProfitCenter",
            "DISMM": "MRPType",
            "DISPO": "MRPResponsible",
            "MMSTA": "CrossPlantStatus",
            "LGFSB": "ProductionInvtryManagedLoc",
            "BSTMI": "MinimumLotSizeQuantity",
            "BESKZ": "ProcurementType",

        },
        
    },



    # ========================================================
    # API_MATERIAL_STOCK_SRV / A_MatlStkInAcctMod
    # ~ MARD
    # ========================================================
    "API_MATERIAL_STOCK_SRV": {
        "A_MatlStkInAcctMod": {
            "MATNR": "Material",
            "WERKS": "Plant",
            "LGORT": "StorageLocation",
            "MEINS": "MaterialBaseUnit",
            "LABST": "MatlWrhsStkQtyInMatlBaseUnit",
        }
    },



    # ========================================================
    # API_MATERIAL_DOCUMENT_SRV / A_MaterialDocumentItem
    # ~ MSEG + MKPF
    # ========================================================
    "API_MATERIAL_DOCUMENT_SRV": {
        "A_MaterialDocumentItem": {
            "MBLNR": "MaterialDocument",
            "MJAHR": "MaterialDocumentYear",
            "ZEILE": "MaterialDocumentItem",

            "MATNR": "Material",
            "WERKS": "Plant",
            "LGORT": "StorageLocation",
            "BWART": "GoodsMovementType",

            "MENGE": "QuantityInEntryUnit",
            "ERFME": "EntryUnit",

            "BUDAT": "PostingDate",
        },

        "A_MaterialDocumentHeader": {
            "MBLNR": "MaterialDocument",
            "MJAHR": "MaterialDocumentYear",
            "BUDAT": "PostingDate",
        },
    },


    # ========================================================
    # API_BUSINESS_PARTNER / A_Supplier
    # ~ LFA1
    # ========================================================
    "API_BUSINESS_PARTNER": {
        "A_Supplier": {
            "LIFNR": "Supplier",
            "NAME1": "SupplierName",

        }
    },
}


# ============================================================
# 2) Độ dài field giống RFC (CHAR length)
# ============================================================

RFC_FIELD_LEN: Dict[str, int] = {
    "MATNR": 40,
    "MBLNR": 10,
    "MJAHR": 4,
    "ZEILE": 4,

    "WERKS": 4,
    "LGORT": 4,
    "BWART": 3,

    "MTART": 4,
    "MEINS": 3,
    "ERFME": 3,

    "ERSDA": 8,
    "LAEDA": 8,
    "BUDAT": 8,

    "ERNAM": 12,
    "AENAM": 12,
}


# ============================================================
# 3) Transform giá trị (ALPHA, DATE…)
# ============================================================

def alpha_input(val: str, length: int = 18) -> str:
    """
    Giống ALPHA INPUT trong SAP:
    - Nếu toàn số => pad 0 bên trái
    - Nếu có chữ => giữ nguyên
    """
    s = (val or "").strip()
    if s.isdigit():
        return s.zfill(length)
    return s


def odata_date_to_yyyymmdd(val: str) -> str:
    """
    Convert SAP OData date:
    - '/Date(1729641600000)/' -> '20241023'
    """
    if not val:
        return ""
    m = re.search(r"/Date\((\-?\d+)", val)
    if not m:
        return val  # nếu không đúng format thì giữ nguyên
    ms = int(m.group(1))
    dt = datetime.fromtimestamp(ms / 1000, tz=timezone.utc)
    return dt.strftime("%Y%m%d")


FIELD_TRANSFORMS: Dict[str, Callable[[str], str]] = {
    "MATNR": lambda v: alpha_input(v, 18),
    # có thể mở rộng:
    # "MBLNR": lambda v: alpha_input(v, 10),
}


DATE_FIELDS = {"ERSDA", "LAEDA", "BUDAT"}


# ============================================================
# 4) Helper functions
# ============================================================

def get_mapping(service_name: str, entity_set: str) -> Dict[str, str]:
    """
    Lấy mapping theo service + entity_set
    """
    s = service_name.strip().upper()
    e = entity_set.strip()

    if s not in SERVICE_ENTITY_MAPPINGS:
        raise KeyError(f"Chưa có mapping cho service: {service_name}")

    if e not in SERVICE_ENTITY_MAPPINGS[s]:
        raise KeyError(f"Chưa có mapping cho entity_set: {service_name} / {entity_set}")

    return SERVICE_ENTITY_MAPPINGS[s][e]


def pad_right(val: str, length: int) -> str:
    """Pad space bên phải giống RFC"""
    return (val or "").ljust(length)


def map_odata_records_to_rfc_like(
    records: list[dict],
    mapping: dict,
    pad: bool = True,
    convert_date: bool = False,
    keep_unmapped: bool = True,
    preserve_odata_order: bool = True,  # ⭐ giữ thứ tự OData
) -> list[dict]:

    # mapping đang là RFC -> OData, đảo lại thành OData -> RFC
    odata_to_rfc = {odata: rfc for rfc, odata in mapping.items()}

    out = []
    for r in records:
        src = {k: v for k, v in r.items() if k != "__metadata"}

        item = {}

        if preserve_odata_order:
            # ✅ đi theo đúng thứ tự key OData trả về
            for o_key, raw_val in src.items():
                if (not keep_unmapped) and (o_key not in odata_to_rfc):
                    continue

                rfc_key = odata_to_rfc.get(o_key, o_key)  # nếu có map thì đổi tên, không có thì giữ nguyên
                val = "" if raw_val is None else str(raw_val)

                # transform (ALPHA…)
                if rfc_key in FIELD_TRANSFORMS:
                    val = FIELD_TRANSFORMS[rfc_key](val)

                # convert date nếu bật (chỉ áp dụng khi key đích là RFC date field)
                if convert_date and rfc_key in DATE_FIELDS:
                    val = odata_date_to_yyyymmdd(val)

                # pad giống RFC nếu bật
                if pad and rfc_key in RFC_FIELD_LEN:
                    val = pad_right(val, RFC_FIELD_LEN[rfc_key])

                item[rfc_key] = val

        else:
            # (fallback) không giữ order OData
            # mapped trước
            for rfc_field, odata_field in mapping.items():
                raw_val = src.get(odata_field, "")
                val = "" if raw_val is None else str(raw_val)

                if rfc_field in FIELD_TRANSFORMS:
                    val = FIELD_TRANSFORMS[rfc_field](val)
                if convert_date and rfc_field in DATE_FIELDS:
                    val = odata_date_to_yyyymmdd(val)
                if pad and rfc_field in RFC_FIELD_LEN:
                    val = pad_right(val, RFC_FIELD_LEN[rfc_field])

                item[rfc_field] = val

            # unmapped sau
            if keep_unmapped:
                mapped_odata_fields = set(mapping.values())
                for k, v in src.items():
                    if k not in mapped_odata_fields:
                        item[k] = v

        out.append(item)

    return out
